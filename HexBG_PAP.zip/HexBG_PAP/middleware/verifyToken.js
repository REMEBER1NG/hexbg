const nedb = require('nedb')

const database = new nedb('../database/users.db')
database.loadDatabase()

function validateUserToken(req, res, next) {
    const token = req.cookies["token"]
    if (token != undefined) {
        database.find({ accessToken: token }, (err, result) => {
            console.log(result)
            next()
        })
    } else next()
}

module.exports = validateUserToken