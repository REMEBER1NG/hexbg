const express = require('express')
const nedb = require('nedb')
const cookieParser = require('cookie-parser')
const crypto = require('crypto')
const verifyToken = require('../middleware/verifyToken')
const router = express.Router()

const database = new nedb('database/users.db')
database.loadDatabase()

router.use(express.json())
router.use(cookieParser())
router.use(verifyToken)

function checkUser(req, res, next) {
    const queryUsername = req.query.p
    database.find({ username: queryUsername }, (err, result) => {
        if (!err) {
            next()
        } else {
            res.send('User does not exist')
        }
    })
}

const date = new Date()

router.get('/register', (req, res) => {
    res.render('auth/userRegister')
})

router.post('/register', (req, res) => {
    const { username, email, password, description } = req.body
    let user = {
        username: username,
        email: email,
        password: password,
        details: {
            profilePic: false,
            active: false,
            description: description,
            timestamp: date.getUTCDate().toString() + '/' +
                date.getUTCMonth().toString() + '/' +
                date.getFullYear().toString(),
        },
        accessToken: crypto.randomBytes(64).toString('hex')
    }
    database.insert(user, (err, result) => {
        if(!err) {
            res.json({ msg: "success" })
        } else {
            res.json({ msg: "error in authentication" })
        }
    })
})

router.get('/login', (req, res) => {
    res.render('auth/userLogin', {
        auth: req.cookies["token"]
    })
})

router.post('/login', (req, res) => {
    const { username, password } = req.body
    database.find({ username, password }, (err, result) => {
        if(!err) {
            if(Object.keys(result).length !== 0) {
                if(result[0]["details"]["active"] !== false) {
                    let userAccessToken = result[0]["accessToken"]
                    res.cookie('token', userAccessToken, {expire: 360000})
                    res.redirect('/home')
                } else {
                    res.json({
                        message: "account is not activated yet"
                    })
                }
            } else {
                res.json({ msg: `${username} account does not exist!` })
            }
        }
    })
})

router.get('/profile', checkUser, (req, res) => {
    const queryUsername = req.query.p
    database.find({ username: queryUsername }, (err, result) => {
        res.render('auth/profile', {
            hasCookie: req.cookies["token"],
            users: result,
            profile: queryUsername,
            followText: 'Follow',
            image: queryUsername + '.jpg',
            status: result[0]["details"]["active"] ? "active" : "inactive" 
        })
    })
})

module.exports = router