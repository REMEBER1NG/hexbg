const authenticationRouter = require('./routes/userAuth')
const verifyToken = require('./middleware/verifyToken')
const express = require('express')
const path = require('path')
const bodyParser = require('body-parser')
const nedb = require('nedb')
const port = process.env.PORT || 9000

const database = new nedb('database/comments.db')
database.loadDatabase()

const app = express()

app.set('view engine', 'ejs')
app.set('views', path.join(__dirname, '/views'))
app.use(express.static(path.join(__dirname, '/static')))
app.use(bodyParser.urlencoded({ extended: true }))
app.use(authenticationRouter)
app.use(verifyToken)
app.use(express.json())

app.get(['/', '/home'], (req, res) => {
    database.find({ }, (err, result) => {
        res.render('index', {
            comms: result, 
            username: "_default.png",
            hasCookie: req.cookies["token"]
        })
    })
})

const date = new Date()

app.post('/home', (req, res) => {
    const { username, comment } = req.body
    let commentData = {
        username: username,
        comment: comment,
        timestamp: {
            day: date.getUTCDate(),
            month: date.getMonth() + 1,
            year: date.getFullYear()
        }
    }
    database.insert(commentData, (err, result) => {
        if (!err) {
            res.redirect('/home')
        }
    })
})

app.get('/tools', (req, res) => {
    res.render('hexbg/tools')
})

app.get('/about', (req, res) => {
    res.render('hexbg/about')
})

app.listen(port, () => { 
    console.log(`Listening on ${port}`)
})
