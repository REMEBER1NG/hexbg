const accountStatusH6 = document.querySelector('#account-status')
const accountStatus = document.querySelector('.status')

const changeTextColor = ( inactiveColor ) => {
    const statusText = accountStatusH6.textContent.split(':')[1]
    if(statusText == ' inactive') {
        accountStatus.style.color = inactiveColor
    }
}

changeTextColor('rgb(255, 107, 107)')