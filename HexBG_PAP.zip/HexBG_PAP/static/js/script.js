const colorInput = document.querySelector('#color-input')
const changeColorButton = document.querySelector('#change-color-button')

changeColorButton.addEventListener('click', () => {
	let hexColor = colorInput.value
	if(hexColor != "") {
		document.body.style.backgroundColor = hexColor
	}
})
