const nextButton = document.querySelector('#next-button')
const registerButton = document.querySelector('#register-b')
const textArea = document.querySelector('#user-description-area')
const usernameInput = document.querySelector('#uname-input')
const emailInput = document.querySelector('#email-input')
const passwordInput = document.querySelector('#password-input')

const nextPageRegister = () => {
    usernameInput.remove() ; emailInput.remove() ; passwordInput.remove()
    nextButton.remove()
    registerButton.style.display = 'block'
    textArea.style.display = 'inline-block'
}

nextButton.addEventListener('click', nextPageRegister)